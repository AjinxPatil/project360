////////////////////////////////////////////////////////////// 
 Mini Calendar Icon Set        
 By Matt Varone 2008        
 http://www.mattvarone.com  
//////////////////////////////////////////////////////////////   

You are free do whatever you want with these icons as long as you don't share or sell them as your own. A credit or link back to http://www.mattvarone.com would be much appreciated. Enjoy!